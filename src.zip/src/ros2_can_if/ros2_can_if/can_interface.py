"""
Author: Ahmed Abdulsahib, Tampere university
Description: This file contains ROS2 node which Recives messages from CAN bus and send publish them to ROS2 topic.
Node inputs:
    - CAN bus message from socketcan
      
Node ouputs:
    - topic: front_axle_IMU
      ROS2 custom message contain the CAN message id, data and dlc. the message is published to topic named can_bus_message.
"""

import rclpy
import time
from rclpy.node import Node
import can
import cantools
import time
import json
from dataclasses import dataclass
from numpy import byte
#from .python_file_name import * #if another python file script in same folder as this one is needed
from can_bus_msg.msg import CanFrame

class CanRos2Interface(Node):
    def __init__(self):
        super().__init__('can_interface_node')
        self.bus = can.interface.Bus(bustype='socketcan', channel='can0', bitrate=500000)
        self.can_msg = CanFrame()
        self.listening_functions = [self.can_message_receiver]
        self.notifire = can.Notifier(self.bus, self.listening_functions)
        self.can_message_publisher = self.create_publisher(CanFrame,'can_bus_message', 0)
        print("Node Class Initialized Successfully")

    def can_message_receiver(self,msg):
        self.can_msg.id = msg.arbitration_id
        self.can_msg.data = msg.data
        self.can_msg.dlc = msg.dlc
        self.can_message_publisher.publish(self.can_msg)

def main(args=None):
    rclpy.init(args=args)
    can_publisher_node = CanRos2Interface()
    rclpy.spin(can_publisher_node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
